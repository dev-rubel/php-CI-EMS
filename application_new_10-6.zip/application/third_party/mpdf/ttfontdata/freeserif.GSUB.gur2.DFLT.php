<?php

$rtlSUB = array();
$finals = '';
$rphf = array (
);
$half = array (
);
$pref = array (
);
$blwf = array (
  2608 => 59400,
  2613 => 59399,
  2617 => 59398,
);
$pstf = array (
  2607 => 59402,
);

 
?>