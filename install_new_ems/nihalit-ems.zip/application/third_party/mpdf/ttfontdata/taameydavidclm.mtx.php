<?php
$name='TaameyDavidCLM-Medium';
$type='TTF';
$desc=array (
  'CapHeight' => 559,
  'XHeight' => 401,
  'FontBBox' => '[-210 -431 887 926]',
  'Flags' => 4,
  'Ascent' => 800,
  'Descent' => -431,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 109,
  'MissingWidth' => 444,
);
$unitsPerEm=2048;
$up=-100;
$ut=34;
$strp=250;
$strs=50;
$ttffile='E:/wamp64/www/bangla_mpdf/mpdf/ttfonts/TaameyDavidCLM-Medium.ttf';
$TTCfontID='0';
$originalsize=96284;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='taameydavidclm';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 800, -200, 90
// usWinAscent/usWinDescent = 800, -431
// hhea Ascent/Descent/LineGap = 800, -431, 90
$useOTL=255;
$rtlPUAstr='\x{0E001}-\x{0E00C}';
$GSUBScriptLang=array (
  'hebr' => 'DFLT ',
);
$GSUBFeatures=array (
  'hebr' => 
  array (
    'DFLT' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 7,
        7 => 8,
        8 => 10,
        9 => 12,
        10 => 13,
        11 => 14,
        12 => 16,
        13 => 18,
        14 => 19,
        15 => 21,
      ),
      'jalt' => 
      array (
        0 => 23,
      ),
      'salt' => 
      array (
        0 => 24,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 33950,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 257,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 34068,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 513,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 34122,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 34518,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 1025,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 34550,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 20,
    'Subtables' => 
    array (
      0 => 34596,
      1 => 34670,
      2 => 34768,
      3 => 34890,
      4 => 35036,
      5 => 35100,
      6 => 35188,
      7 => 35300,
      8 => 35436,
      9 => 35476,
      10 => 35540,
      11 => 35628,
      12 => 35740,
      13 => 35788,
      14 => 35836,
      15 => 35908,
      16 => 35980,
      17 => 36076,
      18 => 36172,
      19 => 36292,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 36412,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 36450,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 24,
    'Subtables' => 
    array (
      0 => 36482,
      1 => 36560,
      2 => 36670,
      3 => 36796,
      4 => 36954,
      5 => 37080,
      6 => 37238,
      7 => 37412,
      8 => 37618,
      9 => 37792,
      10 => 37998,
      11 => 38220,
      12 => 38474,
      13 => 38696,
      14 => 38950,
      15 => 39220,
      16 => 39522,
      17 => 39578,
      18 => 39682,
      19 => 39786,
      20 => 39938,
      21 => 40090,
      22 => 40290,
      23 => 40490,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 2,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 40738,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 40808,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 2,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 41032,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 41974,
      1 => 42148,
      2 => 42336,
      3 => 42480,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 42656,
      1 => 42980,
      2 => 43258,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 43436,
      1 => 43806,
      2 => 44096,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 2,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 44366,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 44646,
      1 => 44810,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 2,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 44926,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 45056,
      1 => 45440,
      2 => 45746,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 45984,
      1 => 46516,
      2 => 47002,
      3 => 47434,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 2,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 47820,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 48090,
      1 => 48168,
      2 => 48254,
      3 => 48340,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48426,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48438,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 48480,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'hebr' => 'DFLT ',
);
$GPOSFeatures=array (
  'hebr' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 5,
        5 => 7,
        6 => 9,
        7 => 11,
        8 => 12,
        9 => 14,
        10 => 15,
        11 => 17,
        12 => 18,
        13 => 22,
        14 => 24,
        15 => 26,
        16 => 27,
        17 => 32,
        18 => 35,
        19 => 37,
        20 => 38,
        21 => 40,
        22 => 42,
        23 => 44,
        24 => 48,
      ),
      'mkmk' => 
      array (
        0 => 20,
        1 => 29,
        2 => 30,
        3 => 31,
        4 => 34,
        5 => 52,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 49396,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 50178,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 50364,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 53222,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 53294,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 55442,
      1 => 55542,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 55622,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57770,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57826,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 59958,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 60012,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 60336,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 61048,
      1 => 61080,
      2 => 61136,
      3 => 61216,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 61320,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 24,
    'Subtables' => 
    array (
      0 => 62040,
      1 => 62096,
      2 => 62136,
      3 => 62200,
      4 => 62240,
      5 => 62304,
      6 => 62334,
      7 => 62414,
      8 => 62518,
      9 => 62646,
      10 => 62710,
      11 => 62798,
      12 => 62886,
      13 => 62998,
      14 => 63110,
      15 => 63246,
      16 => 63310,
      17 => 63398,
      18 => 63486,
      19 => 63598,
      20 => 63710,
      21 => 63846,
      22 => 63900,
      23 => 63978,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 10,
    'Subtables' => 
    array (
      0 => 64080,
      1 => 64182,
      2 => 64274,
      3 => 64342,
      4 => 64418,
      5 => 64494,
      6 => 64620,
      7 => 64736,
      8 => 64828,
      9 => 64928,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 65028,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 65154,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 51,
    'Subtables' => 
    array (
      0 => 72118,
      1 => 72148,
      2 => 72186,
      3 => 72248,
      4 => 72294,
      5 => 72364,
      6 => 72410,
      7 => 72480,
      8 => 72518,
      9 => 72604,
      10 => 72714,
      11 => 72848,
      12 => 72918,
      13 => 73012,
      14 => 73106,
      15 => 73224,
      16 => 73342,
      17 => 73484,
      18 => 73554,
      19 => 73648,
      20 => 73742,
      21 => 73860,
      22 => 73978,
      23 => 74120,
      24 => 74182,
      25 => 74268,
      26 => 74378,
      27 => 74416,
      28 => 74486,
      29 => 74540,
      30 => 74618,
      31 => 74672,
      32 => 74750,
      33 => 74796,
      34 => 74890,
      35 => 75008,
      36 => 75150,
      37 => 75228,
      38 => 75330,
      39 => 75432,
      40 => 75558,
      41 => 75684,
      42 => 75834,
      43 => 75912,
      44 => 76014,
      45 => 76116,
      46 => 76242,
      47 => 76368,
      48 => 76518,
      49 => 76588,
      50 => 76682,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 76800,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 16,
    'Subtables' => 
    array (
      0 => 76814,
      1 => 76932,
      2 => 77060,
      3 => 77202,
      4 => 77354,
      5 => 77486,
      6 => 77628,
      7 => 77784,
      8 => 77950,
      9 => 78042,
      10 => 78144,
      11 => 78260,
      12 => 78386,
      13 => 78470,
      14 => 78564,
      15 => 78672,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 78790,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 78902,
      1 => 78968,
      2 => 79058,
      3 => 79090,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 79146,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 9,
    'Subtables' => 
    array (
      0 => 79878,
      1 => 79984,
      2 => 80138,
      3 => 80340,
      4 => 80452,
      5 => 80612,
      6 => 80820,
      7 => 80892,
      8 => 81012,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 81180,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 81900,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 83400,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 83468,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 84296,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 85226,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 85682,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 86212,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 86306,
    ),
    'MarkFilteringSet' => '',
  ),
  34 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87218,
    ),
    'MarkFilteringSet' => '',
  ),
  35 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 87752,
      1 => 87832,
    ),
    'MarkFilteringSet' => '',
  ),
  36 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 87960,
    ),
    'MarkFilteringSet' => '',
  ),
  37 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88680,
    ),
    'MarkFilteringSet' => '',
  ),
  38 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88738,
    ),
    'MarkFilteringSet' => '',
  ),
  39 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 88772,
    ),
    'MarkFilteringSet' => '',
  ),
  40 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 89494,
    ),
    'MarkFilteringSet' => '',
  ),
  41 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 89532,
    ),
    'MarkFilteringSet' => '',
  ),
  42 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 90254,
    ),
    'MarkFilteringSet' => '',
  ),
  43 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 90286,
    ),
    'MarkFilteringSet' => '',
  ),
  44 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 10,
    'Subtables' => 
    array (
      0 => 91008,
      1 => 91048,
      2 => 91088,
      3 => 91128,
      4 => 91168,
      5 => 91208,
      6 => 91248,
      7 => 91288,
      8 => 91328,
      9 => 91368,
    ),
    'MarkFilteringSet' => '',
  ),
  45 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 91408,
    ),
    'MarkFilteringSet' => '',
  ),
  46 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 92140,
    ),
    'MarkFilteringSet' => '',
  ),
  47 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 92872,
    ),
    'MarkFilteringSet' => '',
  ),
  48 => 
  array (
    'Type' => 8,
    'Flag' => 1,
    'SubtableCount' => 7,
    'Subtables' => 
    array (
      0 => 93604,
      1 => 93648,
      2 => 93688,
      3 => 93728,
      4 => 93768,
      5 => 93808,
      6 => 93848,
    ),
    'MarkFilteringSet' => '',
  ),
  49 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 93888,
    ),
    'MarkFilteringSet' => '',
  ),
  50 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 94620,
    ),
    'MarkFilteringSet' => '',
  ),
  51 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 95352,
    ),
    'MarkFilteringSet' => '',
  ),
  52 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 96084,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>