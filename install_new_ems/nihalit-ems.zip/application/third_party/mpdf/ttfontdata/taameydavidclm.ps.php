<?php 
$originalsize=33496;
?>