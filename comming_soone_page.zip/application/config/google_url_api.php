<?php
/**
 * Register api key: https://code.google.com/apis/console/
 *
 */  
$config['google_api_url'] = 'https://www.googleapis.com/urlshortener/v1/url';
$config['google_api_key'] = 'AIzaSyDUpDXw9XhiwUmLrokGeSTRixHqn03LAoU';

/* End of file Google_url_api.php */
/* Location: ./application/config/Google_url_api.php */

