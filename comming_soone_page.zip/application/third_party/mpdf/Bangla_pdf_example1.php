<?php
$name = 'মো: নুর আলম রুবেল';
$html = '

<html><head>
    
        <style>
		.admitCard:before {
                content: "";
                z-index: -1;
                opacity: 0.2;
                background-size: 220px 225px;
                background-repeat: no-repeat;
                background-image: url("examples/tiger.gif");
                width: 220px;
                height: 225px;
                position: absolute;
                margin-top: -280px;
                display: inline-block;
                left: 320px;
            }
            
		</style>
        

    </head><body style="font-size: 12px; margin: auto 5%;"><div style="">
            <div style="width: 100%; padding-top: 0px;">
                <!--<div class="blnk-space"></div>-->
                <div class="hdr">
                    <div style="width: 100%; height: 150px">
                        <div style="float: left; width: 15%; text-align: center">
                            <img src="examples/tiger.gif" width="100px" height="115px">
                            <div style="margin-top: 15px;"> Serial No: </div>
                        </div>
                        <div style="float: left; width: 65%; text-align: center; line-height: 15px">
                            <h2 class="ex" style="color: green;">Homna Adarsha High School</h2>
                            <h3 style="color: green;">Homna, Comilla</h3>
                            <p>EIIN: 105673, Email: hahs105673@gmail.com</p>
                            <p style="margin-bottom:10px;">Phone: 08025-54244 / 01705 100106</p>
                            <p style="font-size: 13px; width: 150px; padding: 10px; background-color: green; text-align: center; margin: 0 auto; color: white; border: 1px solid black;">Admission Form</p>
                        </div>
                        <div style="float: right; width: 20%; text-align: center">
                            <img src="examples/tiger.gif" width="115px" height="125px" style="border: 1px solid;padding: 2px">
                        </div>
                    </div>
                    <div class="office-part" style="position: relative; line-height: 10px;">
                        <img src="examples/tiger.gif" style="
                             opacity: .2;
                             margin-left: 210px;
                             margin-top: 125px;
                             width: 220px;
                             height: 225px;
                             " />
                        <div style="margin-top: -330px;border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 100%;display:inline-block;margin: 2px 0;color: green;">Student Name : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="font-weight: normal; color: black; font-size: 15px;">'.$name.'</span></p> </div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Student Name (Bangla): </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Fathers Name : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Fathers Name (Bangla): </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Mothers Name : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Mothers Name (Bangla): </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Present Address : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Permanent Address : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Religion : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Nationality : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                        </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Legal Guardian : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Relation : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
					
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Email : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Applied Class : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Group : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
                            <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 650px;display:inline-block;margin: 2px 0;color: green;">JSC Information : <span style="font-weight:normal; font-style: italic; font-size: 12px;">GPA: , Reg No: , Roll No: , Year:</span></p>  </div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Previous School Name: </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Previous School Address : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Date of Birth : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>
                        <div style="border-bottom: 1px solid; border-bottom-style:dotted; font-size: 13px; margin-bottom: 5px;">
  <div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Guardian Mobile No : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div>
                    </div>


                    </div>
                    <div class="commitment-container" style="margin-top: 10px;width: 100%;border-bottom: 1px solid gray;font-size: 12px;line-height: 10px;height: 130px;">
                        <h3 style="width: 30%; text-align: center; border-bottom: 1px solid; margin: 0 auto; padding: 10px 0px; font-size: 13px; margin-top: 10px;color: green;">Commitment Letter</h3>
                        <p style="text-align: center; margin: 10px 0px">I am committed to that, I will obey this school rules. Otherwise school authoritys decision shall be deemed final.</p>
                        <p style="width: 100%; display: inline-block; margin-top: 20px;">&nbsp;&nbsp;&nbsp;Guardian sign: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student Sign:
						<br><br><br>&nbsp;&nbsp;&nbsp;Date: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date:</p>

                    </div>
                    <div style="line-height: 5px; font-size: 12px; height: 150px;">
                        <h3 style="width: 30%;text-align: center;border-bottom: 1px solid;margin: 0 auto;padding-bottom: 10px;padding-top: 5px;font-size: 13px;margin-top: 10px;color: green;">For Office Use</h3>
                        <p style="margin-left: 15px">After taking exam this student considered fit for class ....................... </p>
                        <p style="margin-left: 15px">Information Checker teachers name ......................................................... , Date ..........................................</p>
                        <p style="margin-left: 15px">The Head Teachers orders to admit .......................................................... in class ..........................................</p>
                        <p style="margin-left: 15px">Admission No in Register : </p>
                        <p style="margin-left: 15px">Class Roll No : </p>
                    </div>
                    
					
					
					<!-- ADMIT CARD PORTION -->
					
                    <div style="padding-top: 10px; height: 500px;">
                        <div style="width: 100%; padding-top: 0px;">
                        <div style="float: left; width: 15%; text-align: center">
                            <img src="examples/tiger.gif" width="100px" height="115px">
                            <div style="margin-top: 15px;"> Serial No: </div>
                        </div>
                        <div style="float: left; width: 65%; text-align: center; line-height: 15px">
                            <h2 class="ex" style="color: green;">Homna Adarsha High School</h2>
                            <h3 style="color: green;">Homna, Comilla</h3>
                            <p>EIIN: 105673, Email: hahs105673@gmail.com</p>
                            <p style="margin-bottom:10px;">Phone: 08025-54244 / 01705 100106</p>
                            <p style="font-size: 13px; width: 240px; padding: 10px; background-color: green; text-align: center; margin: 0 auto; color: white; border: 1px solid black;">Admit Card of Admission Exam</p>
                        </div>
                        <div style="float: right; width: 20%; text-align: center">
                            <img src="examples/tiger.gif" width="115px" height="125px" style="border: 1px solid;padding: 2px">
                        </div>
                    </div><br/>
                    <br/>
                    <br/>
                    
                        
                    <div class="admitCard" style="height: 350px;">
					<img src="examples/tiger.gif" style="
                             opacity: .2;
                             margin-left: 210px;
                             margin-top: 0px;
                             width: 220px;
                             height: 225px;
                             " />
                        <div style="margin-top: -250px; border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Student Name : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                        <div style="border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Fathers Name : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                        <div style="border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Applied For Class : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                        <div style="border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Group : </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                        <div style="border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Admission Exam Date: </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                        <div style="border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Admission Exam Time: </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                        <div style="border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Admission Exam Marks: </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                        <div style="border-bottom: 1px dotted !important; font-size: 12px; margin-bottom: 5px;"><div style="margin-bottom: 4px; font-weight: bold;"><p style="width: 250px;display:inline-block;margin: 2px 0;color: green;">Admission Exam Roll: </p> <p style="font-weight: normal; margin: 2px 0; display: inline-block; width: 650px;"></p></div></div>
                    </div>
                    <div style="width: 100%; height: 150px; margin-top: 0px;">
                        <div style="float: left; width: 15%; text-align: center">
                          <p style="border-top: 1px solid gray; border-width: 2px;">Office Seal</p>
                        </div>
                        <div style="float: left; width: 65%; text-align: center; line-height: 15px">
                        </div>
                        <div style="float: right; width: 20%; text-align: center">
                            <p style="border-top: 1px solid gray; border-width: 2px;">Headteacher Sign</p>
                        </div>
                    </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </body></html>

';

include("mpdf.php");
$mpdf=new mPDF('','A4',14,'nikosh'); 
$mpdf->WriteHTML($html);


//$mpdf->MultiCell(100,10,$txt,1,'L',0); 
$mpdf->Output('Hello.pdf','D');
//exit;
?>