<!-- Footer -->
<footer class="main">
	&copy; 2017 <strong>Bidyapith[V1.10]</strong>. 
    Developed by 
	<a href="http://www.nihalit.com" 
    	target="_blank">Nihal IT</a>
</footer>
