<link rel="stylesheet" href="assets/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css">
<script src="assets/js/tinymce/tinymce.min.js"></script>
<script>tinymce.init({ 
    selector:'.editor',
            height: 500,
  plugins: 'table image',
  style_formats: [
    { title: 'Bold text', inline: 'strong' },
    { title: 'Red text', inline: 'span', styles: { color: '#ff0000' } },
    { title: 'Red header', block: 'h1', styles: { color: '#ff0000' } },
    { title: 'Badge', inline: 'span', styles: { display: 'inline-block', border: '1px solid #2276d2', 'border-radius': '5px', padding: '2px 5px', margin: '0 2px', color: '#2276d2' } },
    { title: 'Table row 1', selector: 'tr', classes: 'tablerow1' }
  ],
  formats: {
    alignleft: { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img', classes: 'left' },
    aligncenter: { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img', classes: 'center' },
    alignright: { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img', classes: 'right' },
    alignfull: { selector: 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li,table,img', classes: 'full' },
    bold: { inline: 'span', 'classes': 'bold' },
    italic: { inline: 'span', 'classes': 'italic' },
    underline: { inline: 'span', 'classes': 'underline', exact: true },
    strikethrough: { inline: 'del' }
  },
    });</script>
<link rel="stylesheet" href="assets/css/font-icons/entypo/css/entypo.css">
<link rel="stylesheet" href="assets/css/bootstrap.css">
<link rel="stylesheet" href="assets/css/neon-core.css">
<link rel="stylesheet" href="assets/css/neon-theme.css">
<link rel="stylesheet" href="assets/css/neon-forms.css">
<link href="assets/backend/css/bootstrap-toggle.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/custom.css">
<style>
@font-face { font-family: 'Lobster'; src: url('assets/fonts/Lobster-Regular.ttf'); } 
@font-face { font-family: 'Noto Sans'; src: url('assets/fonts/NotoSans-Regular.ttf'); } 
</style>


<?php if ($text_align == 'right-to-left') : ?>
    <link rel="stylesheet" href="assets/css/neon-rtl.css">
<?php endif; ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="assets/backend/js/jquery.uploadPreview.min.js"></script>    
<link rel="shortcut icon" href="assets/images/favicon.png">
<link rel="stylesheet" href="assets/css/font-icons/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/js/vertical-timeline/css/component.css">
<link rel="stylesheet" href="assets/js/datatables/responsive/css/datatables.responsive.css">
<link rel="stylesheet" href="assets/js/wysihtml5/bootstrap-wysihtml5.css">
<!--for new nav-->
<link rel="stylesheet" href="assets/newNav/newnavstyle.css">
<link rel="stylesheet" href="assets/css/app.min.css">
<link rel="stylesheet" href="assets/backend/css/slide-panel.css">


<!--
<?php
    //$skin_colour = $this->db->get_where('settings' , array(
      //  'type' => 'skin_colour'
   // ))->row()->description; 
   // if ($skin_colour != ''):?>

    <link rel="stylesheet" href="assets/css/skins/<?php //echo $skin_colour;?>.css">

<?php //endif;?>
-->

 <!--[if lt IE 9]><script src="assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->


<script src="assets/newNav/navscrp.js" type="text/javascript"></script>
        <script>
	  $(document).ready(function(){$(".vertical-nav").verticalnav({speed: 400,align: "left"});});
	  </script>

<!--Amcharts-->

<!--
<script src="<?php //echo base_url();?>assets/js/amcharts/amcharts.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/pie.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/serial.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/gauge.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/funnel.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/radar.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/exporting/amexport.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/exporting/rgbcolor.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/exporting/canvg.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/exporting/jspdf.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/exporting/filesaver.js" type="text/javascript"></script>
<script src="<?php //echo base_url();?>assets/js/amcharts/exporting/jspdf.plugin.addimage.js" type="text/javascript"></script>
-->
<script>
    function checkDelete()
    {
        var chk=confirm("Are You Sure To Delete This !");
        if(chk)
        {
          return true;  
        }
        else{
            return false;
        }
    }
</script>