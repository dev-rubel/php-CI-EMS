<style type="text/css">
	@media print 
		 {
		 body { margin: 0; background-color: green; font-size: 12pt; }
		 }
</style>

<div class="row">
	<div class="col-md-10">
		<h2>Today Balance Sheet</h2>
	</div>
	<div class="col-md-2">
		<br>
		<button class="btn btn-md btn-info" onclick="printdiv('today_balance_sheet','Today Balance Sheet')">Print</button>	
	</div>
</div>
<hr>
<div class="row" id="today_balance_sheet">
<div class="col-md-10 col-md-offset-1">
	<div class="col-md-8">
		<p>Today income: </p>
		<p>Today expance: </p>
	</div>
	<div class="col-md-4">
		<p>
			<?php 
				$this->db->select_sum('amount');
				$this->db->where('timestamp >=', strtotime(date('d-m-Y')));
				$this->db->where('timestamp <=', strtotime(date('d-m-Y')));
				$this->db->where('payment_type' , 'income');					
				$income_amount = $this->db->get('payment');
				$income = $income_amount->row()->amount;
				echo $income !=0?$income.' TK/=':0;
			 ?>
		</p>
		<p>
			<?php 
				$this->db->select_sum('amount');
				$this->db->where('timestamp >=', strtotime(date('d-m-Y')));
				$this->db->where('timestamp <=', strtotime(date('d-m-Y')));
				$this->db->where('payment_type' , 'expense');					
				$expense_amount = $this->db->get('payment');
				$expense = $expense_amount->row()->amount;
				echo $expense !=0?$expense.' TK/=':0;
			 ?>
		</p>
		<hr>
		<p>
			<?php echo $income-$expense.' TK/='; ?>
		</p>
	</div>
</div>
</div>

<hr>


<div class="wrapper">
	<div class="row">
		<div class="col-md-10">
			<h2>Monthly Balance Sheet</h2>
		</div>
		<div class="col-md-2">
			<br>
			<button class="btn btn-md btn-info" onclick="printdiv('monthly_balance_sheet','Monthly Balance Sheet')">Print</button>	
		</div>
	</div>
	<hr>
<div id="monthly_balance_sheet">
	<?php foreach(range(1, 12) as $list): 
		$monthName = date('F', mktime(0, 0, 0, $list, 10));
		$first_day_of_month = date('01-m-Y', strtotime('01-'.$list.'-2017'));
		$last_day_of_month = date('t-m-Y', strtotime('01-'.$list.'-2017')); 
	?>
	<div class="row">
	<div class="col-md-10 col-md-offset-1">
		<div class="col-md-2" style="border-right: 1px solid">
			<h3><?php echo $monthName; ?></h3>
		</div>
		<div class="col-md-6">
			<p>Income: <?php echo $first_day_of_month.' <b>to</b> '.$last_day_of_month; ?></p>
			<p>Expance: <?php echo $first_day_of_month.' <b>to</b> '.$last_day_of_month; ?></p>
		</div>
		<div class="col-md-4">
			<p>
				<?php 
					$this->db->select_sum('amount');
					$this->db->where('timestamp >=', strtotime($first_day_of_month));
					$this->db->where('timestamp <=', strtotime($last_day_of_month));
					$this->db->where('payment_type' , 'income');					
					$income_amount = $this->db->get('payment');
					$income = $income_amount->row()->amount;
					echo $income !=0?$income.' TK/=':0;
				 ?>
			</p>
			<p>
				<?php 
					$this->db->select_sum('amount');
					$this->db->where('timestamp >=', strtotime($first_day_of_month));
					$this->db->where('timestamp <=', strtotime($last_day_of_month));
					$this->db->where('payment_type' , 'expense');					
					$expense_amount = $this->db->get('payment');
					$expense = $expense_amount->row()->amount;
					echo $expense !=0?$expense.' TK/=':0;
				 ?>
			</p>
			<hr>
			<p>
				<?php echo $income-$expense.' TK/='; ?>
				<?php $grand_income += $income; $grand_expense += $expense; ?>
			</p>
		</div>
		</div>
	</div>
	<hr>
	<?php endforeach; ?>


	<div class="row">
	<div class="col-md-10 col-md-offset-1">
		<div class="col-md-2" style="border-right: 1px solid">
			<h4><?php echo date('F', mktime(0, 0, 0, 1, 10)).' <b>to</b> '.date('F', mktime(0, 0, 0, 12, 10)); ?></h4>
		</div>
		<div class="col-md-6">
			<p>Income: </p>
			<p>Expance: </p>
		</div>
		<div class="col-md-4">
			<p>
				<?php echo $grand_income.' TK/='; ?>
			</p>
			<p>
				<?php echo $grand_expense.' TK/='; ?>
			</p>
			<hr>
			<p>
				<?php echo $grand_income-$grand_expense.' TK/='; ?>
			</p>
		</div>
	</div>
	</div>

</div>

<script type="text/javascript">
	
	function printdiv(elem, title)
	{
	    var mywindow = window.open('', 'PRINT', 'height=400,width=600');

	    mywindow.document.write('<html><head><title>' + title  + '</title>');
	    mywindow.document.write('<style>.col-md-4{text-align: right;position: relative; top: -65px;}.row{margin-bottom: -43px;}</style>');
	    mywindow.document.write('</head><body>');
	    mywindow.document.write('<h1 style="text-align: center;">' + title  + '</h1>');

	    mywindow.document.write(document.getElementById(elem).innerHTML);
	    mywindow.document.write('</body></html>');

	    mywindow.document.close(); // necessary for IE >= 10
	    mywindow.focus(); // necessary for IE >= 10*/

	    mywindow.print();
	    mywindow.close();

	    return true;
	}
</script>